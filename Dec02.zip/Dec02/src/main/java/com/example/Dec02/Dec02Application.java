package com.example.Dec02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dec02Application {

	public static void main(String[] args) {
		SpringApplication.run(Dec02Application.class, args);
	}

}
